﻿import { Injectable } from '@angular/core';
import { Producto } from '../model/producto/producto';
import { PRODUCTOS } from '../mocks/mock-productos';

@Injectable()
export class ProductoService {
    getProductos():Producto[] {
        return PRODUCTOS;
    }

    /*
        Recibe los productos mediante una promesa - la promesa recogerá el objeto de forma procedural.
    */
    getProductosPromise(): Promise<Producto[]> {
        return Promise.resolve(PRODUCTOS); // resolve recibe el array sustituye el objeto promise por el array.
    }

    getProducto(id: number): Promise<Producto> {
        return this.getProductosPromise().then(
            (producto) => producto.find(producto => producto.id_producto == id)
        );
    }

    main() {
        this.getProductos();    
    }

    getProductosPromiseDelay(): Promise<Producto[]> {
        return new Promise<Producto[]>(
            (resolve) => { setTimeout(resolve, 5000) }
        ).then(() => this.getProductos());
    }
}

/*
 --- acceso externo al servicio.
class test extends ProductoService {
    productos: Producto[] = this.getProducto();
}
*/