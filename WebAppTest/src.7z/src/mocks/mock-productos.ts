import { Producto } from '../model/producto/producto';
import { Image } from '../app/interface/image.interface';

var IMAGES: Image[] = [
    { "title": "diversos tipos de aves", "url": "assets/images/categoria/ave.jpg" },
    { "title": "diversos tipos de cerdo", "url": "assets/images/categoria/cerdo.jpg" },
    { "title": "diversos tipos de cordero", "url": "assets/images/categoria/cordero.jpg" },
    { "title": "diversos tipos de elaborado", "url": "assets/images/categoria/elaborado.jpg" },
    { "title": "diversos tipos de embutidos", "url": "assets/images/categoria/embu.jpg" },
    { "title": "diversos tipos de terneras", "url": "assets/images/categoria/terne.jpg" }
];

export const PRODUCTOS: Producto[] = [
    { id_producto: 11, nombre: 'Aves', descripcion: 'cerdo murciano', precio: 10, tipo: 'cerdo', imagen:IMAGES[0] },
    { id_producto: 12, nombre: 'Cerdo', descripcion: 'pavo murciano', precio: 5, tipo: 'pavo', imagen:IMAGES[1]},
    { id_producto: 13, nombre: 'Cordero y Cabrito', descripcion: 'cordero murciano', precio: 4, tipo: 'cordero', imagen: IMAGES[2] },
    { id_producto: 14, nombre: 'Elaborados', descripcion: 'cerdo murciano', precio: 13, tipo: 'cerdo', imagen:IMAGES[3] },
    { id_producto: 15, nombre: 'Embutidos', descripcion: 'pavo murciano', precio: 43, tipo: 'pavo', imagen:IMAGES[4] },
    { id_producto: 16, nombre: 'Ternera', descripcion: 'cerdo murciano', precio: 5, tipo: 'cerdo', imagen:IMAGES[5] }
];
