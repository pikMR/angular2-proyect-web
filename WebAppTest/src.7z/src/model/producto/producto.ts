import { Image } from '../../app/interface/image.interface';
export class Producto {
    id_producto: number;
    nombre: string;
    descripcion: string;
    precio: number;
    tipo: string;
    imagen: Image;
}
