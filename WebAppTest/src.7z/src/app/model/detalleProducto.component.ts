import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute , Params} from '@angular/router';
import { Location } from '@angular/common';
import { Producto } from '../../model/producto/producto';
import { ProductoService } from '../../services/producto.service';
@Component({
    selector: 'detalle-producto',
    templateUrl: './../views/detalleProducto.component.html',
    styleUrls: ['./../views/detalleProducto.component.css'],
    providers: [ProductoService]
})
export class DetalleProductoComponent implements OnInit{
    @Input() productoSeleccionado: Producto;
    @Input('titulo') titulo: string;
    constructor(private productoService: ProductoService,
                private route: ActivatedRoute,
                private location: Location
        ) {

    }
    ngOnInit(): void {
        this.route.params.forEach(
            (params: Params) =>
            {
                let id = +params['id'];
                this.productoService.getProducto(id).then(
                    producto => this.productoSeleccionado = producto
                );
            }
        );
    }

    isAtras() {
        this.location.back();
    }

}
