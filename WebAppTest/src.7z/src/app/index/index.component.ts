﻿import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';

@Component({
    selector: 'app-index',
    templateUrl: './index.component.html',
    styleUrls: ['./index.component.css']
    //providers: [ProductoService] -- necesario para saber que servicios se usarán.
})

export class IndexComponent{
}
